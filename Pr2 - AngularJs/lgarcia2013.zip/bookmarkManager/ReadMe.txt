Created by: Lukas W. Garcia
Z#: Z23237934
Date: June 17, 2017
Class: Cutting-Edge Web Technologies



Current working version can be found at: http://lamp.cse.fau.edu/~lgarcia2013/p2/



*At the moment localStorage is not running correctly